package com.vogella.jersey.first;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonWriter;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import redis.clients.jedis.*;

/*
HSET authors 'author:1' 'Winston Churchill'
HSET authors 'author:2' 'Jeffrey Lebowski'
SADD 'quote:1' 'I may be drunk, Miss, but in the morning I will be sober and you will still be ugly.'
SADD 'quote:1' 'If you are going through hell, keep going.'
SADD 'quote:2' 'The rug really tied the room together.'
SADD 'quote:2' 'Yeah, well, you know, that's just, like, your opinion, man.'
*/

//Sets the path to base URL + /hello
@Path("/quotes")
public class Helloworld {
	
	
	@GET
	@Produces({"text/html"})
	public String getAll() {
		String html = "<body>";
		String magic = "";
				
		Jedis jedis = new Jedis("localhost");
		
		for(int i = 0 ; i < jedis.hlen("authors") ; ++i) {
			int number = i + 1;
			magic += "<strong>"+jedis.hget("authors", ("author:"+number))+"</strong><br/>";
			magic += jedis.smembers("quote:"+number);
			magic += "<br/>";
		}
		
		html += magic+"</body>";
		return html;
	}
	
	@GET
	@Path("{name}")
	@Produces({"text/html"})
	public String getAllFrom(@PathParam("name") String name) {
	
		String html = "<body>";
		String magic = "";

		Jedis jedis = new Jedis("localhost");
		
		int number = 1;
		Boolean found = false;
		
		do {
			String currentName = jedis.hget("authors", ("author:"+number));
			
			if(currentName.equals(name)) {
				found = true;
				magic = "<strong>"+name+"</strong><br/>"+jedis.smembers("quote:"+number);
			}
			else {
				++number;
				magic = "<strong>not found</storng>";
			}
		} while(!found && number <= jedis.hlen("authors"));
		
		return html += magic;	
	}
}
